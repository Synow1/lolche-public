Pretendard 1.3.9 (https://github.com/orioncactus/pretendard) — SIL Open Font License 1.1
KS X 1001 서브셋 (Regular/Medium/SemiBold/Bold/ExtraBold). 없는 글자는 시스템 글꼴로.
